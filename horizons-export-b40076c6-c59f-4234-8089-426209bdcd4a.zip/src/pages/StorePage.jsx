
import React from 'react';
import { Helmet } from 'react-helmet';
import { HeroSection } from '@/components/HeroSection';
import { CategoriesSection } from '@/components/CategoriesSection';
import ProductsList from '@/components/ProductsList';
import { NewsletterSection } from '@/components/NewsletterSection';

function StorePage() {
  return (
    <>
      <Helmet>
        <title>سوق اليمن - كنوز الأصالة بين يديك</title>
        <meta name="description" content="سوق اليمن، بوابتك الأولى للمنتجات اليمنية الأصيلة. اكتشف العقيق اليماني، العسل، البن، والملابس التقليدية." />
        <meta property="og:title" content="سوق اليمن - كنوز الأصالة بين يديك" />
        <meta property="og:description" content="سوق اليمن، بوابتك الأولى للمنتجات اليمنية الأصيلة. اكتشف العقيق اليماني، العسل، البن، والملابس التقليدية." />
      </Helmet>
      <HeroSection />
      <CategoriesSection />
      <section id="products" className="section-padding">
        <div className="container mx-auto px-4">
            <div className="text-center mb-12">
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    منتجاتنا المميزة
                </h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                    أفضل المنتجات اليمنية المختارة بعناية لتلبية جميع احتياجاتك.
                </p>
            </div>
            <ProductsList />
        </div>
      </section>
      <NewsletterSection />
    </>
  );
}

export default StorePage;
