
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ShoppingBag } from 'lucide-react';

function SuccessPage() {
  return (
    <>
      <Helmet>
        <title>تم الدفع بنجاح! - سوق اليمن</title>
        <meta name="description" content="شكراً لطلبك! تم استلام دفعتك بنجاح." />
      </Helmet>
      <div className="container mx-auto px-4 py-16 flex items-center justify-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white p-12 rounded-2xl shadow-xl max-w-2xl"
        >
          <CheckCircle className="mx-auto h-24 w-24 text-green-500" />
          <h1 className="text-4xl font-extrabold text-gray-800 mt-6 mb-4">
            شكراً لك على طلبك!
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            لقد استلمنا دفعتك بنجاح. سيتم تجهيز طلبك من كنوز اليمن وشحنه قريباً. ستتلقى رسالة تأكيد عبر البريد الإلكتروني تحتوي على تفاصيل طلبك.
          </p>
          <Link
            to="/"
            className="inline-flex items-center justify-center btn-primary text-white px-8 py-3 rounded-full font-bold text-lg"
          >
            <ShoppingBag className="ml-2" />
            متابعة التسوق
          </Link>
        </motion.div>
      </div>
    </>
  );
}

export default SuccessPage;
