import React, { createContext, useState, useEffect, useContext } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const isSupabaseConnected = !!supabase;

  useEffect(() => {
    if (!isSupabaseConnected) {
      setLoading(false);
      return;
    }

    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
      setLoading(false);
    };

    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null);
        setLoading(false);
      }
    );

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, [isSupabaseConnected]);

  const handleAuthAction = async (action, options) => {
    if (!isSupabaseConnected) {
       console.error("Supabase not configured.");
       return { error: { message: "Supabase not configured." } };
    }
    const { data, error } = await action(options);
    if (error) {
      toast({
        title: "حدث خطأ",
        description: error.message,
        variant: "destructive",
      });
    }
    return { data, error };
  };

  const value = {
    signUp: (options) => handleAuthAction(supabase.auth.signUp, options),
    signInWithPassword: (options) => handleAuthAction(supabase.auth.signInWithPassword, options),
    signInWithOAuth: (options) => handleAuthAction(supabase.auth.signInWithOAuth, options),
    signOut: () => handleAuthAction(supabase.auth.signOut),
    user,
    loading,
    isSupabaseConnected,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};