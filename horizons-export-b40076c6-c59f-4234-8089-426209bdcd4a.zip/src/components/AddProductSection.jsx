import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Link, PlusCircle } from 'lucide-react';

export function AddProductSection({ onAddProduct }) {
  const [productUrl, setProductUrl] = useState('');
  const { toast } = useToast();

  const handleAddProduct = () => {
    if (!productUrl.trim()) {
      toast({
        title: "خطأ",
        description: "الرجاء إدخال رابط المنتج.",
        variant: "destructive",
      });
      return;
    }

    // This is a mock implementation.
    // In a real app, you would fetch data from the URL.
    const newProduct = {
      name: "منتج جديد من الرابط",
      price: `${Math.floor(Math.random() * 500) + 50} ريال`,
      oldPrice: `${Math.floor(Math.random() * 200) + 550} ريال`,
      rating: (Math.random() * (5 - 4) + 4).toFixed(1),
      reviews: Math.floor(Math.random() * 100),
      image: "A newly added product from a URL"
    };

    onAddProduct(newProduct);
    setProductUrl('');
    toast({
      title: "نجاح!",
      description: "تمت إضافة المنتج بنجاح.",
    });
  };

  return (
    <section id="add-product" className="section-padding bg-gray-100">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-white p-8 rounded-2xl shadow-lg text-center"
        >
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            أضف منتجاً جديداً
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            هل لديك منتج تود إضافته؟ الصق الرابط هنا وسنقوم بالباقي!
          </p>
          
          <div className="max-w-2xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-grow">
                <Link className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <Input
                  type="url"
                  placeholder="https://example.com/product-url"
                  value={productUrl}
                  onChange={(e) => setProductUrl(e.target.value)}
                  className="w-full px-6 py-3 pr-12 rounded-full border-gray-300 focus:ring-primary text-right"
                />
              </div>
              <Button 
                onClick={handleAddProduct}
                className="btn-primary text-white px-8 py-3 rounded-full font-bold"
              >
                <PlusCircle className="ml-2" size={20} />
                إضافة المنتج
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}