import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { ShoppingCart, Star } from 'lucide-react';

export function ProductsSection({ products }) {
  const handleAction = () => {
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  return (
    <section id="products" className="section-padding">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            منتجاتنا المميزة
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            أفضل المنتجات المختارة بعناية لتلبية جميع احتياجاتك.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-md overflow-hidden product-card text-right"
            >
              <div className="relative">
                <img  alt={product.name} className="w-full h-56 object-cover" src="https://images.unsplash.com/photo-1635865165118-917ed9e20936" />
                <div className="absolute top-4 right-4 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full">
                  خصم
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-bold text-xl mb-2">{product.name}</h3>
                <div className="flex justify-end items-center mb-3">
                  <span className="text-gray-500 text-sm ml-2">({product.reviews} مراجعة)</span>
                  <span className="font-bold text-yellow-500 ml-1">{product.rating}</span>
                  <Star size={16} className="text-yellow-400" fill="currentColor" />
                </div>
                <div className="flex justify-end items-baseline mb-4">
                  <span className="font-extrabold text-2xl text-primary">{product.price}</span>
                  <span className="text-gray-400 line-through text-md mr-2">{product.oldPrice}</span>
                </div>
                <Button onClick={handleAction} className="w-full btn-primary font-bold">
                  <ShoppingCart className="ml-2" size={20} />
                  أضف إلى السلة
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}