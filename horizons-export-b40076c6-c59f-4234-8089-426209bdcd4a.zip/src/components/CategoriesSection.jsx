
import React from 'react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { Smartphone, Shirt, Home, Heart, Coffee, Gem } from 'lucide-react';

export function CategoriesSection() {
    const { toast } = useToast();
  const handleAction = () => {
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  const categories = [
    { name: 'عقيق يماني', icon: <Gem size={32} /> },
    { name: 'ملابس تقليدية', icon: <Shirt size={32} /> },
    { name: 'منتجات منزلية', icon: <Home size={32} /> },
    { name: 'عسل وقهوة', icon: <Coffee size={32} /> },
    { name: 'صحة وجمال', icon: <Heart size={32} /> },
    { name: 'إلكترونيات', icon: <Smartphone size={32} /> },
  ];

  return (
    <section id="categories" className="section-padding bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            تصفح حسب الفئات
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            اكتشف مجموعتنا الواسعة من المنتجات اليمنية الأصيلة.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {categories.map((category, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              onClick={handleAction}
              className="flex flex-col items-center justify-center p-6 rounded-2xl bg-gray-100 hover:bg-primary hover:text-white transition-all duration-300 cursor-pointer group"
            >
              <div className="text-primary group-hover:text-white transition-colors duration-300 mb-3">
                {category.icon}
              </div>
              <h3 className="font-bold text-lg text-center">
                {category.name}
              </h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
