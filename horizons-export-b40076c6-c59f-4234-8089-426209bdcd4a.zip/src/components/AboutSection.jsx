
import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Award, Heart } from 'lucide-react';

export function AboutSection() {
  return (
    <section id="about" className="section-padding bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-gradient mb-6">
            عن الكتاب
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            رحلة استكشافية عميقة في عالم تحقيق الأحلام والوصول إلى النجاح الحقيقي
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {[
            {
              icon: <BookOpen className="text-amber-500" size={40} />,
              title: "محتوى غني",
              description: "12 فصلاً مليئاً بالحكم والنصائح العملية لتحقيق أهدافك"
            },
            {
              icon: <Award className="text-amber-500" size={40} />,
              title: "خبرة عملية",
              description: "استراتيجيات مجربة من خبراء النجاح والتطوير الشخصي"
            },
            {
              icon: <Heart className="text-amber-500" size={40} />,
              title: "تحفيز حقيقي",
              description: "قصص ملهمة وتمارين عملية لبناء الثقة وتحقيق التميز"
            }
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="text-center p-8 rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50 hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="font-display text-2xl font-semibold text-gray-800 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
