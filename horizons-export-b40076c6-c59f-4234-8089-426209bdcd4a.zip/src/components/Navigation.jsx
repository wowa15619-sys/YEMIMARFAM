
import React, { useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Menu, X } from 'lucide-react';

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { scrollY } = useScroll();
  const headerOpacity = useTransform(scrollY, [0, 100], [0.9, 1]);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  const handlePurchase = () => {
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  return (
    <motion.nav 
      style={{ opacity: headerOpacity }}
      className="fixed top-0 w-full z-50 glass-effect"
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="font-display text-2xl font-bold text-gradient"
          >
            رحلة إلى النجوم
          </motion.div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8 space-x-reverse">
            {[
              { name: 'حول', id: 'about' },
              { name: 'معاينة', id: 'preview' },
              { name: 'المؤلف', id: 'author' },
              { name: 'المراجعات', id: 'reviews' }
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-gray-700 hover:text-amber-600 transition-colors duration-300 font-medium"
              >
                {item.name}
              </button>
            ))}
          </div>

          <div className="hidden md:block">
            <Button 
              onClick={handlePurchase}
              className="btn-primary text-white px-6 py-2 rounded-full font-semibold"
            >
              اشترِ الآن
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-gray-700"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden mt-4 pb-4"
          >
            <div className="flex flex-col space-y-4">
              {[
                { name: 'حول', id: 'about' },
                { name: 'معاينة', id: 'preview' },
                { name: 'المؤلف', id: 'author' },
                { name: 'المراجعات', id: 'reviews' }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-gray-700 hover:text-amber-600 transition-colors duration-300 font-medium text-right"
                >
                  {item.name}
                </button>
              ))}
              <Button 
                onClick={handlePurchase}
                className="btn-primary text-white px-6 py-2 rounded-full font-semibold"
              >
                اشترِ الآن
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
}
