
import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

export function ReviewsSection() {
  return (
    <section id="reviews" className="section-padding bg-gradient-to-br from-amber-50 to-orange-100">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-gradient mb-6">
            آراء القراء
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            اكتشف كيف غيّر هذا الكتاب حياة آلاف القراء حول العالم
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              name: "سارة أحمد",
              role: "رائدة أعمال",
              rating: 5,
              review: "كتاب رائع غيّر نظرتي للحياة تماماً. الآن أشعر بثقة أكبر في قدرتي على تحقيق أحلامي."
            },
            {
              name: "محمد علي",
              role: "مهندس",
              rating: 5,
              review: "أسلوب المؤلف بسيط وعملي. طبقت النصائح وحققت تقدماً ملحوظاً في مسيرتي المهنية."
            },
            {
              name: "فاطمة حسن",
              role: "طالبة جامعية",
              rating: 5,
              review: "كتاب ملهم جداً! ساعدني في تنظيم وقتي وتحديد أولوياتي بشكل أفضل."
            },
            {
              name: "عبدالله محمد",
              role: "مدير تسويق",
              rating: 5,
              review: "محتوى قيّم ومفيد. أنصح كل من يريد تطوير نفسه بقراءة هذا الكتاب."
            },
            {
              name: "نورا سالم",
              role: "معلمة",
              rating: 5,
              review: "كتاب يستحق القراءة! التمارين العملية ساعدتني كثيراً في تحقيق أهدافي."
            },
            {
              name: "خالد يوسف",
              role: "طبيب",
              rating: 5,
              review: "أسلوب شيق وممتع. الكتاب مليء بالحكم والنصائح التي تطبق في الحياة اليومية."
            }
          ].map((review, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} size={16} fill="currentColor" />
                  ))}
                </div>
              </div>
              <Quote className="text-amber-500 mb-3" size={24} />
              <p className="text-gray-600 leading-relaxed mb-4">
                "{review.review}"
              </p>
              <div className="border-t pt-4">
                <p className="font-semibold text-gray-800">{review.name}</p>
                <p className="text-sm text-gray-500">{review.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
