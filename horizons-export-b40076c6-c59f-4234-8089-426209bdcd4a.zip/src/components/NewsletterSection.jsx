
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Mail } from 'lucide-react';

export function NewsletterSection() {
  const { toast } = useToast();
  const handleNewsletter = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  return (
    <section className="section-padding bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            انضم إلى قائمتنا البريدية
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            كن أول من يعرف عن كنوزنا الجديدة والعروض الحصرية القادمة من اليمن.
          </p>
          
          <form onSubmit={handleNewsletter} className="max-w-lg mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="أدخل بريدك الإلكتروني"
                className="flex-1 px-6 py-3 rounded-full border border-gray-300 focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-right"
                required
              />
              <Button 
                type="submit"
                className="btn-primary text-white px-8 py-3 rounded-full font-bold"
              >
                <Mail className="ml-2" size={20} />
                اشتراك
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
