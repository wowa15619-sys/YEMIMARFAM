
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { ShoppingCart } from 'lucide-react';

export function PricingSection() {
  const handlePurchase = () => {
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  return (
    <section className="section-padding bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-gradient mb-6">
            احصل على نسختك الآن
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            استثمر في مستقبلك واحصل على الكتاب بأفضل سعر
          </p>
        </motion.div>

        <div className="max-w-md mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="bg-gradient-to-br from-amber-50 to-orange-100 p-8 rounded-2xl shadow-xl border-2 border-amber-200 relative"
          >
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-amber-500 text-white px-6 py-2 rounded-full font-bold">
              عرض محدود
            </div>
            
            <div className="text-center">
              <h3 className="font-display text-2xl font-bold text-gray-800 mb-4">
                النسخة الرقمية
              </h3>
              <div className="mb-6">
                <span className="text-4xl font-bold text-gradient">99</span>
                <span className="text-xl text-gray-600 mr-2">ريال</span>
                <div className="text-sm text-gray-500 line-through">149 ريال</div>
              </div>
              
              <ul className="text-right space-y-3 mb-8">
                <li className="flex items-center">
                  <span className="text-green-500 ml-3">✓</span>
                  كتاب رقمي بصيغة PDF
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 ml-3">✓</span>
                  12 فصل مليء بالمحتوى القيم
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 ml-3">✓</span>
                  تمارين عملية قابلة للتطبيق
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 ml-3">✓</span>
                  دعم فني مجاني
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 ml-3">✓</span>
                  ضمان استرداد المال لمدة 30 يوم
                </li>
              </ul>
              
              <Button 
                onClick={handlePurchase}
                className="btn-primary text-white px-8 py-4 rounded-full font-semibold text-lg w-full pulse-glow"
              >
                <ShoppingCart className="ml-2" size={20} />
                اشترِ الآن
              </Button>
              
              <p className="text-sm text-gray-500 mt-4">
                دفع آمن ومضمون • تحميل فوري
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
