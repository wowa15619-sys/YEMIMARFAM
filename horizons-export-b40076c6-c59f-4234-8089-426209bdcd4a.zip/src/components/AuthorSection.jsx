
import React from 'react';
import { motion } from 'framer-motion';
import { Award, User, Star, BookOpen } from 'lucide-react';

export function AuthorSection() {
  return (
    <section id="author" className="section-padding bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-right"
          >
            <h2 className="font-display text-4xl lg:text-5xl font-bold text-gradient mb-6">
              عن المؤلف
            </h2>
            <h3 className="font-display text-2xl font-semibold text-gray-800 mb-4">
              د. أحمد النجار
            </h3>
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              خبير في التطوير الشخصي والقيادة مع أكثر من 15 عاماً من الخبرة في مساعدة الأشخاص على تحقيق أهدافهم. حاصل على دكتوراه في علم النفس التطبيقي ومؤلف لأكثر من 8 كتب في مجال التنمية البشرية.
            </p>
            <div className="space-y-3">
              <div className="flex items-center justify-center lg:justify-start">
                <Award className="text-amber-500 ml-3" size={20} />
                <span className="text-gray-700">مؤلف أكثر من 8 كتب</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start">
                <User className="text-amber-500 ml-3" size={20} />
                <span className="text-gray-700">مدرب معتمد دولياً</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start">
                <Star className="text-amber-500 ml-3" size={20} />
                <span className="text-gray-700">ساعد أكثر من 50,000 شخص</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex justify-center"
          >
            <div className="relative">
              <img  
                alt="صورة المؤلف د. أحمد النجار"
                className="w-80 h-80 rounded-full object-cover shadow-2xl"
                src="https://images.unsplash.com/photo-1688484185622-3cd9878ebe73" />
              <div className="absolute -bottom-4 -right-4 bg-amber-500 text-white p-4 rounded-full">
                <BookOpen size={24} />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
