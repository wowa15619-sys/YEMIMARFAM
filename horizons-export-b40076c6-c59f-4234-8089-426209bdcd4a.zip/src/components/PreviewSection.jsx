
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Download } from 'lucide-react';

export function PreviewSection() {
  const handlePurchase = () => {
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  return (
    <section id="preview" className="section-padding bg-gradient-to-br from-amber-50 to-orange-100">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-gradient mb-6">
            معاينة الفصول
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            اطلع على محتوى الكتاب واكتشف الرحلة التي ستغير حياتك
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { title: "الفصل الأول: بداية الرحلة", description: "كيف تحدد أهدافك وترسم خريطة طريقك نحو النجاح" },
            { title: "الفصل الثاني: قوة الإرادة", description: "تطوير العزيمة والمثابرة لتجاوز التحديات" },
            { title: "الفصل الثالث: فن التخطيط", description: "استراتيجيات عملية لوضع خطط قابلة للتحقيق" },
            { title: "الفصل الرابع: إدارة الوقت", description: "كيف تستثمر وقتك بأفضل طريقة ممكنة" },
            { title: "الفصل الخامس: بناء العادات", description: "تكوين عادات إيجابية تقودك للنجاح" },
            { title: "الفصل السادس: التفكير الإيجابي", description: "تحويل التحديات إلى فرص للنمو والتطور" }
          ].map((chapter, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-amber-100"
            >
              <h3 className="font-display text-xl font-semibold text-gray-800 mb-3">
                {chapter.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {chapter.description}
              </p>
              <Button 
                onClick={handlePurchase}
                variant="outline" 
                className="mt-4 border-amber-500 text-amber-700 hover:bg-amber-50"
              >
                <Download className="ml-2" size={16} />
                قراءة المزيد
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
