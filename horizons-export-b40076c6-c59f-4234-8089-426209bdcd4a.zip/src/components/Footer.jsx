
import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export function Footer() {
  const { toast } = useToast();
  const handleSocialClick = (socialMedia) => {
    toast({
      title: `🚧 الانتقال إلى ${socialMedia}`,
      description: "هذه الميزة غير مُفعّلة بعد، ولكن يمكنك طلبها لاحقاً! 🚀",
    });
  };

  const handleLinkClick = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  return (
    <footer className="bg-yemen-black text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 text-right">
          <div>
            <h3 className="text-xl font-bold text-gradient mb-4">
              سوق اليمن
            </h3>
            <p className="text-gray-400 leading-relaxed">
              بوابتك إلى كنوز اليمن. منتجات أصيلة من أرض الأصالة إلى باب بيتك.
            </p>
            <div className="flex space-x-4 space-x-reverse mt-6 justify-end">
              <button onClick={() => handleSocialClick('Facebook')} className="text-gray-400 hover:text-white"><Facebook /></button>
              <button onClick={() => handleSocialClick('Twitter')} className="text-gray-400 hover:text-white"><Twitter /></button>
              <button onClick={() => handleSocialClick('Instagram')} className="text-gray-400 hover:text-white"><Instagram /></button>
            </div>
          </div>
          
          <div>
            <span className="font-bold text-lg mb-4 block">روابط مهمة</span>
            <ul className="space-y-2">
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">عن سوق اليمن</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">الوظائف</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">سياسة الخصوصية</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">الشروط والأحكام</a></li>
            </ul>
          </div>

          <div>
            <span className="font-bold text-lg mb-4 block">خدمة العملاء</span>
            <ul className="space-y-2">
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">مركز المساعدة</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">كيفية الشراء</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">سياسة الإرجاع</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white transition-colors">تتبع طلبك</a></li>
            </ul>
          </div>
          
          <div>
            <span className="font-bold text-lg mb-4 block">تواصل معنا</span>
            <div className="space-y-3">
              <div className="flex items-center justify-end">
                <span className="text-gray-400">support@souq-yemen.com</span>
                <Mail className="mr-3" size={16} />
              </div>
              <div className="flex items-center justify-end">
                <span className="text-gray-400">+967 777 123 456</span>
                <Phone className="mr-3" size={16} />
              </div>
              <div className="flex items-center justify-end">
                <span className="text-gray-400">صنعاء، اليمن</span>
                <MapPin className="mr-3" size={16} />
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 سوق اليمن. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
}
