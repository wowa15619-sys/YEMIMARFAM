
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/context/AuthContext';
import { Menu, X, Search, User, Heart, ShoppingCart as ShoppingCartIcon, LogOut, LogIn } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Header({ setIsCartOpen, setIsAuthModalOpen }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { toast } = useToast();
  const { cartItems } = useCart();
  const { user, signOut } = useAuth();
  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleAction = () => {
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  const handleSignOut = async () => {
    await signOut();
    toast({
      title: "تم تسجيل الخروج بنجاح!",
    });
  };

  const getInitials = (name) => {
    if (!name) return 'U';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  return (
    <header className="sticky top-0 w-full z-40 bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Link to="/" className="text-2xl font-extrabold text-gradient">
              سوق اليمن
            </Link>
          </motion.div>

          <div className="hidden lg:flex flex-1 max-w-xl mx-8">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="ابحث عن منتجات يمنية أصيلة..."
                className="w-full px-4 py-2 pr-12 rounded-full border border-gray-300 focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-right"
              />
              <Button onClick={handleAction} size="icon" className="absolute left-1 top-1/2 -translate-y-1/2 h-8 w-10 bg-primary rounded-full">
                <Search className="h-5 w-5 text-white" />
              </Button>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-6 space-x-reverse">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                    <Avatar>
                      <AvatarImage src={user.user_metadata?.avatar_url} alt={user.user_metadata?.full_name} />
                      <AvatarFallback>{getInitials(user.user_metadata?.full_name || user.email)}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal text-right">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.user_metadata?.full_name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleAction} className="justify-end">
                    <span>ملفي الشخصي</span>
                    <User className="mr-2 h-4 w-4" />
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleAction} className="justify-end">
                    <span>طلباتي</span>
                    <ShoppingCartIcon className="mr-2 h-4 w-4" />
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-red-500 focus:text-red-500 justify-end">
                    <span>تسجيل الخروج</span>
                    <LogOut className="mr-2 h-4 w-4" />
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <button onClick={() => setIsAuthModalOpen(true)} className="flex items-center text-gray-600 hover:text-primary transition-colors">
                <User className="ml-1" />
                <span>حسابي</span>
              </button>
            )}
            <button onClick={handleAction} className="flex items-center text-gray-600 hover:text-primary transition-colors">
              <Heart className="ml-1" />
              <span>المفضلة</span>
            </button>
            <button onClick={() => setIsCartOpen(true)} className="flex items-center text-gray-600 hover:text-primary transition-colors relative">
              <ShoppingCartIcon className="ml-1" />
              <span>السلة</span>
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
          </div>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-gray-700"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        <nav className="hidden md:flex justify-center items-center py-2 border-t border-gray-200">
          <ul className="flex space-x-8 space-x-reverse font-medium text-gray-600">
            {['الكل', 'عروض خاصة', 'عقيق يماني', 'ملابس', 'بهارات', 'عسل', 'بن'].map(cat => (
              <li key={cat}>
                <a href="#" onClick={handleAction} className="hover:text-primary transition-colors">{cat}</a>
              </li>
            ))}
          </ul>
        </nav>

        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden mt-4 pb-4 border-t"
          >
            <div className="flex flex-col space-y-4 pt-4">
              {['الكل', 'عروض خاصة', 'عقيق يماني', 'ملابس', 'بهارات', 'عسل', 'بن'].map(cat => (
                <a key={cat} href="#" onClick={handleAction} className="text-gray-700 hover:text-primary transition-colors duration-300 text-right font-medium">
                  {cat}
                </a>
              ))}
              <div className="border-t my-4"></div>
              {user ? (
                <>
                  <button onClick={handleAction} className="flex items-center justify-end text-gray-600 hover:text-primary transition-colors">
                    <span>ملفي الشخصي</span>
                    <User className="mr-2" />
                  </button>
                  <button onClick={handleSignOut} className="flex items-center justify-end text-red-500 hover:text-red-600 transition-colors">
                    <span>تسجيل الخروج</span>
                    <LogOut className="mr-2" />
                  </button>
                </>
              ) : (
                <button onClick={() => { setIsAuthModalOpen(true); setIsMenuOpen(false); }} className="flex items-center justify-end text-gray-600 hover:text-primary transition-colors">
                  <span>تسجيل الدخول</span>
                  <LogIn className="mr-2" />
                </button>
              )}
              <button onClick={handleAction} className="flex items-center justify-end text-gray-600 hover:text-primary transition-colors">
                <span>المفضلة</span>
                <Heart className="mr-2" />
              </button>
              <button onClick={() => { setIsCartOpen(true); setIsMenuOpen(false); }} className="flex items-center justify-end text-gray-600 hover:text-primary transition-colors">
                <span>السلة</span>
                <ShoppingCartIcon className="mr-2" />
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </header>
  );
}
