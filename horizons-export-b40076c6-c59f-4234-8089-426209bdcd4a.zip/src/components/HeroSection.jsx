
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft } from 'lucide-react';

export function HeroSection() {
  const { toast } = useToast();
  const handleAction = () => {
    toast({
      title: "🚧 هذه الميزة غير مُفعّلة بعد",
      description: "لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  return (
    <section className="bg-white">
      <div className="container mx-auto px-4 py-8">
        <div className="relative rounded-2xl overflow-hidden h-80 md:h-[500px] flex items-center justify-end p-8 md:p-16 text-right">
          <img 
            alt="منظر لمدينة صنعاء القديمة في اليمن"
            className="absolute inset-0 w-full h-full object-cover"
           src="https://images.unsplash.com/photo-1547844320-7baa9e4082be" />
          <div className="absolute inset-0 bg-black bg-opacity-50"></div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="relative z-10 text-white max-w-lg"
          >
            <h1 className="text-4xl md:text-6xl font-extrabold mb-4 leading-tight">
              تراث اليمن في متناول يديك
            </h1>
            <p className="text-lg md:text-xl mb-6">
              اكتشف كنوز اليمن الأصيلة، من الحرف اليدوية إلى المنتجات الطبيعية.
            </p>
            <Button 
              onClick={handleAction}
              className="btn-primary text-white px-8 py-3 rounded-full font-bold text-lg"
            >
              استكشف الآن
              <ArrowLeft className="mr-2" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
